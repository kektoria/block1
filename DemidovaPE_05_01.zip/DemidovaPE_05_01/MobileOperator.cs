﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DemidovaPE_05_01;

namespace DemidovaPE_05_01
{
    //Класс "мобильный оператор"
    public class MobileOperator
    {
        string nameOperator;
        double minutePrice, coverageArea;

        //конструктор класса
        public MobileOperator(string nameOperator, double minutePrice, double coverageArea)
        {
            this.nameOperator = nameOperator;
            this.minutePrice = minutePrice;
            this.coverageArea = coverageArea;
        }

        //функция поиска Q
        public double findQ()
        {
            double q;
            q = 100 * coverageArea / minutePrice;
            return q;
        }
    }

    
}
