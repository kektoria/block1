﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemidovaPE_05_01
{
    class Program
    {
        static void Main(string[] args)
        {
            string nameOperator;
            double minutePrice, coverageArea;
            int p;

            Console.WriteLine("Введите название мобильного оператора");
            nameOperator = Console.ReadLine();
            if(nameOperator == "")
            {
                Console.WriteLine("Вводимая информация не должна быть пустой!");
                return;
            }

            Console.WriteLine("Введите стоимость 1 минуты разговора");
            if (!double.TryParse(Console.ReadLine(), out minutePrice))
            {
                Console.WriteLine("Введите число!");
                return;
            }

            Console.WriteLine("Введите площадь покрытия");
            if (!double.TryParse(Console.ReadLine(), out coverageArea))
            {
                Console.WriteLine("Введите число!");
                return;
            }

            FeeCalculation feeCalculation = new FeeCalculation(nameOperator, minutePrice, coverageArea, p);

            Console.WriteLine("Вы оплачивали соединение? Выберите 0(нет) или 1(да)");

            if (Convert.ToInt32(!int.TryParse(Console.ReadLine(), out p)) == 0)
            {
                Console.WriteLine($"QP = {feeCalculation.findQP()}");
            }

            Console.ReadKey();
        }
    }
}
