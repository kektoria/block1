﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DemidovaPE_05_01;

namespace DemidovaPE_05_01
{
    //Класс "расчет оплаты"
    public class FeeCalculation : MobileOperator
    {
        string nameOperator;
        double minutePrice, coverageArea;
        int p;

        //Конструктор класса
        public FeeCalculation(string nameOperator, double minutePrice, double coverageArea, int p) : base(nameOperator, minutePrice, coverageArea)
        {
            this.nameOperator = nameOperator;
            this.minutePrice = minutePrice;
            this.coverageArea = coverageArea;
            this.p = p;
        }

        //Метод для поиска QP
        public double findQP()
        {
            double qp = 0.0;

            //если Р - ложь
            if (p == 0)
            {
                qp = 1.5 * findQ();
            }

            //если Р - истина
            else if (p == 1)
            {
                qp = 0.7 * findQ();
            }

            return qp;
        }

        
    }
}
